<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Assessment task master</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link type="text/css" rel="preload" href="<?php echo e(asset('Toaster')); ?>/toast.style.min.css" as="style"
        onload="this.onload=null;this.rel='stylesheet'">
    <style>
        .field-error {
            color: red
        }
    </style>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('footer_scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ikonic-assessment\resources\views/master.blade.php ENDPATH**/ ?>