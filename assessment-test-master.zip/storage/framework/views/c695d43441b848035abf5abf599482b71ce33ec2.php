<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
    crossorigin="anonymous"></script>
<script src="<?php echo e(asset('Toaster')); ?>/toast.script.js"></script>
<script>
    function IsEmail(new_email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/
        if (!regex.test(new_email)) {
            return false
        } else {
            return true
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\ikonic-assessment\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>